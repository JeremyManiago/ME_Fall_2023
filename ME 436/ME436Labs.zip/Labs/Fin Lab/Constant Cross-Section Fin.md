## Data Sheet
+ [[FinData.txt]] | [[Uncertainty.txt]]
	+ [-] [[fin_rawdata.xlsx]]

## Manual
- Chapter 8 (p. 56)
	- 8.5 Report (p. 58)
## MATLAB
- [[constant_fin.mlx]]
	- [[constant_fin.m]] (lab report Appendix D)

## Report
- [[JeremyManiago_fin.docx]]
	- ![[JeremyManiago_fin.pdf]]