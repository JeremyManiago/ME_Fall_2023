## Data Sheet
- [[Pelton Wheel Experiment Data Sheet.pdf]]
	- [[pelton_wheel_rawdata.xlsx]]
## Manual
- Chapter 9 (p. 67)
	- 9.4 Report (p. 73)
## MATLAB
- [[pelton_wheel.m]]

## Report
- [[JeremyManiago_peltonwheel.docx]]
	- ![[JeremyManiago_peltonwheel.pdf]]