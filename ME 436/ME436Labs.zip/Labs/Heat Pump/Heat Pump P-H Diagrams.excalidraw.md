---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
h2 ^VIvquaVe

h3,h4 ^nh4B4prH

h1 ^nZfghm8z

Data 1 ^BSrIciWO


# Embedded files
93551dcdc7769f7b7dfad690e2ec5cbbb1b7ca68: [[Pasted Image 20231203091009_941.png]]
51ad43f62927c24d7cd1bc617c74f978db52b6bc: [[Pasted Image 20231203095957_420.png]]

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/2.0.4",
	"elements": [
		{
			"type": "image",
			"version": 413,
			"versionNonce": 663694436,
			"isDeleted": false,
			"id": "MbXBbaryKbaCxQHtnlUyJ",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 40,
			"angle": 0,
			"x": 226.88750000000005,
			"y": 79.4795106132076,
			"strokeColor": "transparent",
			"backgroundColor": "transparent",
			"width": 1162.725,
			"height": 877.5283018867924,
			"seed": 2002964188,
			"groupIds": [
				"G6ZbVFnv1vbQpw3AyGCEs"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": null,
			"updated": 1701614172203,
			"link": null,
			"locked": false,
			"status": "pending",
			"fileId": "93551dcdc7769f7b7dfad690e2ec5cbbb1b7ca68",
			"scale": [
				1,
				1
			]
		},
		{
			"type": "line",
			"version": 472,
			"versionNonce": 87293924,
			"isDeleted": false,
			"id": "TjqmwM9oXG94g9xNrQ8_r",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 959.75,
			"y": 352.78125,
			"strokeColor": "#e03131",
			"backgroundColor": "transparent",
			"width": 282,
			"height": 1,
			"seed": 1517171044,
			"groupIds": [
				"G6ZbVFnv1vbQpw3AyGCEs"
			],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1701614172203,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-282,
					-1
				]
			]
		},
		{
			"type": "line",
			"version": 308,
			"versionNonce": 233988964,
			"isDeleted": false,
			"id": "Yk07_YkxlIn8VjVtWfyE6",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 959.75,
			"y": 351.78125,
			"strokeColor": "#e03131",
			"backgroundColor": "transparent",
			"width": 58,
			"height": 114,
			"seed": 1928053468,
			"groupIds": [
				"G6ZbVFnv1vbQpw3AyGCEs"
			],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1701614172203,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					58,
					-114
				]
			]
		},
		{
			"type": "line",
			"version": 225,
			"versionNonce": 1209554660,
			"isDeleted": false,
			"id": "PzWi8TiKGx1Se-FoCxyAk",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 680.25,
			"y": 237.5170990566038,
			"strokeColor": "#e03131",
			"backgroundColor": "transparent",
			"width": 336,
			"height": 1,
			"seed": 646731620,
			"groupIds": [
				"G6ZbVFnv1vbQpw3AyGCEs"
			],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1701614172203,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					336,
					-1
				]
			]
		},
		{
			"type": "line",
			"version": 202,
			"versionNonce": 1077140068,
			"isDeleted": false,
			"id": "C5owCnQIZYFJYViplwqyq",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 679.25,
			"y": 237.5170990566038,
			"strokeColor": "#e03131",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 112,
			"seed": 770442972,
			"groupIds": [
				"G6ZbVFnv1vbQpw3AyGCEs"
			],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1701614172203,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0,
					112
				]
			]
		},
		{
			"type": "line",
			"version": 533,
			"versionNonce": 1091759588,
			"isDeleted": false,
			"id": "R6zOV31yccutmslSmk5bG",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 675.25,
			"y": 857.5170990566038,
			"strokeColor": "#e03131",
			"backgroundColor": "transparent",
			"width": 3,
			"height": 620,
			"seed": 1702484956,
			"groupIds": [
				"G6ZbVFnv1vbQpw3AyGCEs"
			],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1701614172203,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					3,
					-620
				]
			]
		},
		{
			"type": "line",
			"version": 637,
			"versionNonce": 197366116,
			"isDeleted": false,
			"id": "OJ8RAyZqXYY5qiACZ9-2A",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1015.75,
			"y": 862.5170990566039,
			"strokeColor": "#e03131",
			"backgroundColor": "transparent",
			"width": 1,
			"height": 625,
			"seed": 1367582564,
			"groupIds": [
				"G6ZbVFnv1vbQpw3AyGCEs"
			],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1701614172203,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					1,
					-625
				]
			]
		},
		{
			"type": "text",
			"version": 249,
			"versionNonce": 261342436,
			"isDeleted": false,
			"id": "VIvquaVe",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1022.25,
			"y": 809.5170990566038,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 40.04296875,
			"height": 41.4,
			"seed": 268953700,
			"groupIds": [
				"G6ZbVFnv1vbQpw3AyGCEs"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": null,
			"updated": 1701614172203,
			"link": null,
			"locked": false,
			"fontSize": 36,
			"fontFamily": 2,
			"text": "h2",
			"rawText": "h2",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "h2",
			"lineHeight": 1.15,
			"baseline": 33
		},
		{
			"type": "text",
			"version": 280,
			"versionNonce": 571574372,
			"isDeleted": false,
			"id": "nh4B4prH",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 683.5420074462891,
			"y": 805.0170990566038,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 105.46875,
			"height": 43.199999999999996,
			"seed": 1374456028,
			"groupIds": [
				"G6ZbVFnv1vbQpw3AyGCEs"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1701614172203,
			"link": null,
			"locked": false,
			"fontSize": 36,
			"fontFamily": 3,
			"text": "h3,h4",
			"rawText": "h3,h4",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "h3,h4",
			"lineHeight": 1.2,
			"baseline": 35
		},
		{
			"type": "text",
			"version": 253,
			"versionNonce": 923458532,
			"isDeleted": false,
			"id": "nZfghm8z",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 907.5420074462891,
			"y": 811.0170990566038,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 40.04296875,
			"height": 41.4,
			"seed": 1242297188,
			"groupIds": [
				"G6ZbVFnv1vbQpw3AyGCEs"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1701614172203,
			"link": null,
			"locked": false,
			"fontSize": 36,
			"fontFamily": 2,
			"text": "h1",
			"rawText": "h1",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "h1",
			"lineHeight": 1.15,
			"baseline": 33
		},
		{
			"type": "line",
			"version": 693,
			"versionNonce": 411942756,
			"isDeleted": false,
			"id": "xuBBoN9OLPQlCAQws-Y75",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 956.75,
			"y": 861.0170990566039,
			"strokeColor": "#e03131",
			"backgroundColor": "transparent",
			"width": 2,
			"height": 507,
			"seed": 1801892316,
			"groupIds": [
				"G6ZbVFnv1vbQpw3AyGCEs"
			],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1701614172203,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					2,
					-507
				]
			]
		},
		{
			"id": "BSrIciWO",
			"type": "text",
			"x": 380.25,
			"y": 313.5170990566038,
			"width": 106.06640625,
			"height": 41.4,
			"angle": 0,
			"strokeColor": "#2f9e44",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [
				"AJVdCKJbIdhkVFadpJ1w5",
				"G6ZbVFnv1vbQpw3AyGCEs"
			],
			"frameId": null,
			"roundness": null,
			"seed": 674510564,
			"version": 411,
			"versionNonce": 518533860,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1701614172203,
			"link": null,
			"locked": false,
			"text": "Data 1",
			"rawText": "Data 1",
			"fontSize": 36,
			"fontFamily": 2,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 33,
			"containerId": null,
			"originalText": "Data 1",
			"lineHeight": 1.15
		},
		{
			"id": "OmWaq3pZeNb5xoY4S4pw3",
			"type": "rectangle",
			"x": 373.25,
			"y": 308.5170990566038,
			"width": 121,
			"height": 49,
			"angle": 0,
			"strokeColor": "#2f9e44",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [
				"AJVdCKJbIdhkVFadpJ1w5",
				"G6ZbVFnv1vbQpw3AyGCEs"
			],
			"frameId": null,
			"roundness": {
				"type": 3
			},
			"seed": 986215780,
			"version": 389,
			"versionNonce": 1755854436,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1701614172203,
			"link": null,
			"locked": false
		},
		{
			"id": "s7GmgMnveufkHIV3wTYJ0",
			"type": "ellipse",
			"x": 667.25,
			"y": 851.5170990566038,
			"width": 15,
			"height": 15,
			"angle": 0,
			"strokeColor": "#e03131",
			"backgroundColor": "#e03131",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [
				"G6ZbVFnv1vbQpw3AyGCEs"
			],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"seed": 1205395804,
			"version": 134,
			"versionNonce": 312199652,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1701614172203,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 171,
			"versionNonce": 1875963236,
			"isDeleted": false,
			"id": "LBGmjATsO2X3kUSUbITtt",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 948.75,
			"y": 850.0170990566038,
			"strokeColor": "#e03131",
			"backgroundColor": "#e03131",
			"width": 15,
			"height": 15,
			"seed": 326690788,
			"groupIds": [
				"G6ZbVFnv1vbQpw3AyGCEs"
			],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1701614172203,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 152,
			"versionNonce": 1100325092,
			"isDeleted": false,
			"id": "myyHYS0ZsrqHoCf3qesBY",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1007.75,
			"y": 849.0170990566038,
			"strokeColor": "#e03131",
			"backgroundColor": "#e03131",
			"width": 15,
			"height": 15,
			"seed": 1446686436,
			"groupIds": [
				"G6ZbVFnv1vbQpw3AyGCEs"
			],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1701614172203,
			"link": null,
			"locked": false
		},
		{
			"id": "hrXs5Vvk-TTde1ZLKPwjg",
			"type": "image",
			"x": 320.48976608187104,
			"y": -150.80600035860107,
			"width": 1004.8502994011978,
			"height": 194.00000000000006,
			"angle": 0,
			"strokeColor": "transparent",
			"backgroundColor": "#e03131",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"seed": 1753785828,
			"version": 140,
			"versionNonce": 31980260,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "ovkMbtUoFMt6zvBaNeTC9",
					"type": "arrow"
				},
				{
					"id": "E17QZLw4c11GnsiKBAy00",
					"type": "arrow"
				},
				{
					"id": "UmRWSEjoFzMjJCJvxe9Rl",
					"type": "arrow"
				}
			],
			"updated": 1701615624058,
			"link": null,
			"locked": false,
			"status": "pending",
			"fileId": "51ad43f62927c24d7cd1bc617c74f978db52b6bc",
			"scale": [
				1,
				1
			]
		},
		{
			"id": "ovkMbtUoFMt6zvBaNeTC9",
			"type": "arrow",
			"x": 274.98976608187104,
			"y": -105.30600035860107,
			"width": 40,
			"height": 0,
			"angle": 0,
			"strokeColor": "#e03131",
			"backgroundColor": "#e03131",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"seed": 814581476,
			"version": 28,
			"versionNonce": 1744096860,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1701615601944,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					40,
					0
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": {
				"elementId": "hrXs5Vvk-TTde1ZLKPwjg",
				"focus": 0.5309278350515463,
				"gap": 5.5
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"type": "arrow",
			"version": 50,
			"versionNonce": 1860132316,
			"isDeleted": false,
			"id": "E17QZLw4c11GnsiKBAy00",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 275.98976608187104,
			"y": 31.693999641398932,
			"strokeColor": "#e03131",
			"backgroundColor": "#e03131",
			"width": 40,
			"height": 0,
			"seed": 455684572,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1701615621704,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": {
				"elementId": "hrXs5Vvk-TTde1ZLKPwjg",
				"focus": -0.8814432989690719,
				"gap": 4.5
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					40,
					0
				]
			]
		},
		{
			"type": "arrow",
			"version": 73,
			"versionNonce": 1236789212,
			"isDeleted": false,
			"id": "UmRWSEjoFzMjJCJvxe9Rl",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 272.98976608187104,
			"y": -61.30600035860107,
			"strokeColor": "#e03131",
			"backgroundColor": "#e03131",
			"width": 40,
			"height": 0,
			"seed": 158323940,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1701615639384,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": {
				"elementId": "hrXs5Vvk-TTde1ZLKPwjg",
				"focus": 0.07731958762886619,
				"gap": 7.5
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					40,
					0
				]
			]
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#e03131",
		"currentItemBackgroundColor": "#e03131",
		"currentItemFillStyle": "solid",
		"currentItemStrokeWidth": 2,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 0,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 2,
		"currentItemFontSize": 36,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 225.01023391812896,
		"scrollY": 549.8372503586011,
		"zoom": {
			"value": 1
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"gridColor": {
			"Bold": "#C9C9C9FF",
			"Regular": "#EDEDEDFF"
		},
		"currentStrokeOptions": null,
		"previousGridSize": null,
		"frameRendering": {
			"enabled": true,
			"clip": true,
			"name": true,
			"outline": true
		}
	},
	"files": {}
}
```
%%