## Data
+ [[Data 33F.xlsx]]
+ [[Data 36F.xlsx]]
+ [[Data 37F.xlsx]]
+ [[Data 38F.xlsx]]
+ [[Data 39F.xlsx]]
+ [[Data 40F.xlsx]]
+ [[Data 41F.xlsx]]

## Manual
- ![[Experiment_Heat Pump Lab.pdf]]
## MATLAB
- [[heat_pump.mlx]]

## Excalidraw
- P-H Diagram
![[Heat Pump P-H Diagrams.excalidraw|900]]
## Report
- [[JeremyManiago_heatpump.docx]]