## Data Sheet
- [[Viscous Pipe Experiment Data Sheet.pdf]]
	- [[viscous_pipe_rawdata.xlsx]]
## Manual
- Chapter 6 (p. 39)
	- 6.6 Report (p. 46)
## MATLAB
- [[viscous_pipe.m]]

## Report
- [[JeremyManiago_viscouspipe.docx]]
	- ![[JeremyManiago_viscouspipe.pdf]]